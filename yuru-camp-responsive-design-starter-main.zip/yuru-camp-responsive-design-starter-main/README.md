# YuruCamp - Barebones HTML + CSS

Starter files - Implement Responsive Design for Mobile Device

### To download this repo:
```bash
> cd your/preferred/directory
> git clone https://github.com/andasan/yuru-camp-responsive-design-starter
```